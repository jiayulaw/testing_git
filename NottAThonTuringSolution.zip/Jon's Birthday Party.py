
numberFren = input()
frens = input().split()
filling = input().split()
prize = input().split()
frens = [int(integer) for integer in frens]
filling = [int(integer) for integer in filling]
prize = [int(integer) for integer in prize]




class Solution:
    def combinationSum(self, candidates, price, target):
        self.res = []
        self.sum = 0
        self.finalSum = 0
        self.candidates = candidates
        self.backtrack([], 0, target)
        for i in range(len(self.res)):
            for j in range(len(self.res[i])):
                for k in range(3): 
                    if(self.res[i][j] == self.candidates[k]):
                        self.sum = self.sum + price[k]
                        break
            if(i==0):
                self.finalSum = self.sum
            if self.sum < self.finalSum :
                self.finalSum = self.sum
            self.sum = 0
        return self.finalSum
    
    def backtrack(self, path, indx, target):
        if target < 0:
            return
        
        if target == 0:
            self.res.append(path)
            return 
        
        for x in range(indx, len(self.candidates)):
            self.backtrack(path+[self.candidates[x]], x, target - self.candidates[x])

ob1 = Solution()



# frens = [455,5,3,56,7]
totalsum = 0
for i in frens:
    totalsum = totalsum + ob1.combinationSum(filling,prize,i)
print(totalsum)




