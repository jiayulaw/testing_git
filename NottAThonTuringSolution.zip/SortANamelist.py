name = input()
x = name.split(',')
hyphen = []
nohyphen = []

for i in range(len(x)):
    for j in range(len(x[i])):
        if x[i][j] == '-':
            hyphen.append(x[i])
            nohyphen.append(x[i].replace('-',' '))

if len(hyphen) > 0:
    for i in range(len(nohyphen)):
        if nohyphen[i] in x:
            x.remove(nohyphen[i])


def sortFunction(x,y,z):
    for i in range(len(x)):
        for j in range(len(x[i])):
            if x[i][j] == ' ' or x[i][j] == '-':
                y = y+1
            if x[i][j] == '-':
                x[i]= x[i].replace('-',' ')
        if y == 1:
            z = x[i].split(' ')
            # print(z)
            x[i] = ''
            x[i]  = z[1] + ' ' + z[0]
        y = 0
        z = []
    return x

x2 = sortFunction(x,0,[])
x2.sort()
xSort = sortFunction(x2,0,[])
x3 = list(dict.fromkeys(xSort))

if len(hyphen) > 0:
    for i in range(len(nohyphen)):
        if nohyphen[i] in x3:
            x3 = [w.replace(nohyphen[i], hyphen[i]) for w in x3]

separator = ','
x3 = separator.join(x3)
print(x3)











