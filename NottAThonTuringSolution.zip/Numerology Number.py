n=int(input())
strn1=str(n)
while n>9:
    strn=str(n)
    
    
    string=""
    for i in range(len(strn)):
        string+=strn[i]
        if i<len(strn):
            string+=" "

        else:
            string=string
    Sum=0
    for j in strn:
        Sum+=int(j)

    print(string)
    print(Sum)
    n=Sum
even=0
odd=0
for ii in strn1:
    if int(ii)%2==0:
        even+=1
    else:
        odd+=1
print(even)
print(odd)
    
