import fileinput

n = 0

NSS = []
Query = []

line = input()
line = line.split()
N = int(line[0])
Q = int(line[1])

for n in range(N):
    NSS.append(input())

for n in range(Q):
    Query.append(input())

#find parents
names = []
for line in NSS:
    if(line.count(".")):
        name = ""
        flag = 0
        for i in line:
            if(i == "."):
                flag = 1
                name = "."
                continue
            elif(i == "," or i == "{"):
                if(flag):
                    names.append(name)
                flag = 0
                continue
            name += i


names = [name.strip() for name in names]

names = list(dict.fromkeys(names))

dictlist = [dict() for x in range(len(names))]

def getDictFromName(name, names):
    return dictlist[names.index(name)]

def addProperty(line, dict):
    split = line.split(":")
    dict[split[0].strip()] = split[1].strip()[:-1]

#add properties
noi = []
inBody = 0
for line in NSS:
        name = ""
        flag = 0
        charnum = 0
        for i in line:
            if(charnum == 0 and i == "/"):
                break
            charnum += 1
            if(i == "."):
                flag = 1
                name = "."
                continue
            elif(i == ","):
                if(flag):
                    noi.append(name)
                flag = 0
                continue
            elif(i == "{"):
                if(flag):
                    noi.append(name)
                flag = 0
                inBody = 1

                noi = [name.strip() for name in noi]

                noi = list(dict.fromkeys(noi))
                continue
            elif(i == "}"):
                inBody = 0
                noi = []
                name = ""
                flag = 0
                continue
            elif(inBody):
                if noi:
                    for name in noi:
                        addProperty(line, getDictFromName(name, names))
                break
            name += i

#process querys
#find name

for line in Query:
    if(line[24] != "."):
        print("Not Found!")
    else:
        name = "."
        end = 0
        for i in range(len(line)):
            if(line[i+25] == "'"):
                end = i+25
                break
            name += line[i+25]
        property = line[end+3:]
        if name in names:
            if property in getDictFromName(name, names):
                print(getDictFromName(name, names)[property])
            else:
                print("Not Found!")
        else:
            print("Not Found!")