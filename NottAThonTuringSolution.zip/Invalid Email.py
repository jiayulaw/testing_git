n = 0
emails = []
validSymbols = ['-', '.', '_']
N = int(input())

for n in range(N):
    emails.append(input())

for email in emails:
    if(email[0].isalpha()):
        if(email.count("@") != 1):
            continue

        #find @ split name
        name = email[:email.index("@")-1]
        #check name
        error = 0
        for c in name:
            if(c.isalnum() or c in validSymbols):
                pass
            else:
                error = 1
                break
        if error:
            continue

        #split domain
        domain = email[email.index("@")+1:]
        #check domain
        if(domain.count(".") > 2):
            continue
        else:
            stripped = ""
            for x in domain.split("."):
                stripped += x
            if(stripped.isalpha()):
                print(email)
            else:
                continue


    else:
        continue